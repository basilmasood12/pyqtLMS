from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QCheckBox, QPushButton,
    QListWidget, QMessageBox, QVBoxLayout, QInputDialog
)
import sys
from book_library import Book, EBook, Library, BookNotAvailableError

class LibraryApp(QWidget):
    def __init__(self):
        super().__init__()
        self.library = Library()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Library Manager")
        self.setGeometry(100, 100, 600, 600)

        self.layout = QVBoxLayout()

        
        self.label_title = QLabel("Title:")
        self.input_title = QLineEdit()

        self.label_author = QLabel("Author:")
        self.input_author = QLineEdit()

        self.label_isbn = QLabel("ISBN:")
        self.input_isbn = QLineEdit()

        self.checkbox_digital = QCheckBox("Is Digital?")
        self.label_size = QLabel("File Size (MB):")
        self.input_size = QLineEdit()

        
        self.btn_add = QPushButton("Add Book")
        self.btn_lend = QPushButton("Lend Book")
        self.btn_return = QPushButton("Return Book")
        self.btn_remove = QPushButton("Remove Book")
        self.btn_search = QPushButton("Search Books by Author")

        
        self.label_list = QLabel("Book Inventory:")
        self.book_list = QListWidget()

        
        for widget in [
            self.label_title, self.input_title,
            self.label_author, self.input_author,
            self.label_isbn, self.input_isbn,
            self.checkbox_digital, self.label_size, self.input_size,
            self.btn_add, self.btn_lend, self.btn_return,
            self.btn_remove, self.btn_search,
            self.label_list, self.book_list
        ]:
            self.layout.addWidget(widget)

        self.setLayout(self.layout)

        
        self.btn_add.clicked.connect(self.add_book)
        self.btn_lend.clicked.connect(self.lend_book)
        self.btn_return.clicked.connect(self.return_book)
        self.btn_remove.clicked.connect(self.remove_book)
        self.btn_search.clicked.connect(self.search_by_author)

        self.update_list()

    def add_book(self):
        title = self.input_title.text()
        author = self.input_author.text()
        isbn = self.input_isbn.text()
        is_digital = self.checkbox_digital.isChecked()
        size = self.input_size.text()

        if not title or not author or not isbn:
            QMessageBox.critical(self, "Error", "Title, Author, and ISBN are required.")
            return

        if is_digital and not size:
            QMessageBox.critical(self, "Error", "Download size required for digital books.")
            return

        book = EBook(title, author, isbn, size) if is_digital else Book(title, author, isbn)
        self.library.add_book(book)
        QMessageBox.information(self, "Success", f"'{title}' has been added.")
        self.update_list()

    def lend_book(self):
        isbn, ok = QInputDialog.getText(self, "Lend Book", "Enter ISBN:")
        if ok and isbn:
            try:
                self.library.lend_book(isbn)
                QMessageBox.information(self, "Success", "Book has been lent.")
                self.update_list()
            except BookNotAvailableError as e:
                QMessageBox.critical(self, "Error", str(e))

    def return_book(self):
        isbn, ok = QInputDialog.getText(self, "Return Book", "Enter ISBN:")
        if ok and isbn:
            try:
                self.library.return_book(isbn)
                QMessageBox.information(self, "Success", "Book returned.")
                self.update_list()
            except BookNotAvailableError as e:
                QMessageBox.critical(self, "Error", str(e))

    def remove_book(self):
        isbn, ok = QInputDialog.getText(self, "Remove Book", "Enter ISBN:")
        if ok and isbn:
            self.library.remove_book(isbn)
            QMessageBox.information(self, "Success", "Book removed.")
            self.update_list()

    def search_by_author(self):
        author, ok = QInputDialog.getText(self, "Search by Author", "Enter author:")
        if ok and author:
            books = list(self.library.books_by_author(author))
            self.book_list.clear()
            if books:
                self.book_list.addItem(f"Books by {author}:")
                for b in books:
                    self.book_list.addItem(str(b))
            else:
                QMessageBox.information(self, "No Results", "No books found for this author.")

    def update_list(self):
        self.book_list.clear()
        self.book_list.addItem("Currently Available Books:")
        for book in self.library:
            self.book_list.addItem(str(book))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LibraryApp()
    window.show()
    sys.exit(app.exec_())
